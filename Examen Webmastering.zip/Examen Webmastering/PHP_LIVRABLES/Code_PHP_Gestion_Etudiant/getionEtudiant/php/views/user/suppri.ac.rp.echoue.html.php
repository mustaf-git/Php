<h1>Aucune suppression n'a été effectuée</h1>
<a name="" id="" class="btn btn-primary" href="<?php path('user/supprimerAcRp/')?>" role="button">Supprimer encore</a>