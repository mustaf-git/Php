<h1>Aucune données données de connexion n'a été modifier</h1>
<a name="" id="" class="btn btn-primary" href="<?php path('user/modifConnection/')?>" role="button">modifier encore</a>