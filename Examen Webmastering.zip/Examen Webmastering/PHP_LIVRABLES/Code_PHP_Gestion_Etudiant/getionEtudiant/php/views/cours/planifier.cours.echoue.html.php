<h1>planification de cours non acceptée</h1>
<a name="" id="" class="btn btn-primary" href="<?php path('cours/choixPlanifierCours/')?>" role="button">planifier encore</a>