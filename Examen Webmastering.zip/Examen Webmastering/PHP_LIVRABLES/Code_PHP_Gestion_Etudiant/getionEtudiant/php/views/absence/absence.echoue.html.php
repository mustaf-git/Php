<h1>Impossible d'enregistrer une absence plus d'une fois  </h1>
<a name="" id="" class="btn btn-primary" href="<?php path('absence/enregistrerAbsence/')?>" role="button">Marquer Absence</a>