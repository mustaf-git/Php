<h1>Absence enregistrer avec succes</h1>
<a name="" id="" class="btn btn-primary" href="<?php path('absence/enregistrerAbsence/')?>" role="button">Marquer Absence</a>