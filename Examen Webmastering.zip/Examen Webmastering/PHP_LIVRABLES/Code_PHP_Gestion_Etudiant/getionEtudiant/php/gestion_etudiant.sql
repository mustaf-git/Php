-- phpMyAdmin SQL Dump
-- version 5.0.2
-- https://www.phpmyadmin.net/
--
-- Hôte : 127.0.0.1:3306
-- Généré le : jeu. 01 juil. 2021 à 23:00
-- Version du serveur :  5.7.31
-- Version de PHP : 7.3.21

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Base de données : `gestion_etudiant`
--

-- --------------------------------------------------------

--
-- Structure de la table `absence`
--

DROP TABLE IF EXISTS `absence`;
CREATE TABLE IF NOT EXISTS `absence` (
  `idAbsence` int(11) NOT NULL AUTO_INCREMENT,
  `dateAbsence` date NOT NULL,
  `idEtu` varchar(255) NOT NULL,
  `idCours` int(11) NOT NULL,
  PRIMARY KEY (`idAbsence`),
  KEY `idCours` (`idCours`),
  KEY `id` (`idEtu`) USING BTREE
) ENGINE=MyISAM AUTO_INCREMENT=30 DEFAULT CHARSET=latin1;

--
-- Déchargement des données de la table `absence`
--

INSERT INTO `absence` (`idAbsence`, `dateAbsence`, `idEtu`, `idCours`) VALUES
(1, '2021-06-03', '11', 1),
(2, '2021-06-10', '6', 3),
(3, '2021-06-10', '9', 3),
(29, '2021-07-01', '9', 5),
(28, '2021-06-30', '11', 5),
(27, '2021-06-29', '11', 3),
(26, '2021-06-29', '10', 8),
(25, '2021-06-29', '19', 6),
(24, '2021-06-29', '10', 3),
(23, '2021-06-29', '15', 3);

-- --------------------------------------------------------

--
-- Structure de la table `classe`
--

DROP TABLE IF EXISTS `classe`;
CREATE TABLE IF NOT EXISTS `classe` (
  `libelleCl` varchar(255) NOT NULL,
  `niveauCl` varchar(255) NOT NULL,
  `filiereCl` varchar(255) NOT NULL,
  PRIMARY KEY (`libelleCl`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Déchargement des données de la table `classe`
--

INSERT INTO `classe` (`libelleCl`, `niveauCl`, `filiereCl`) VALUES
('MAE2', 'L2', 'MAE'),
('GLRS2A', 'L2', 'GLRS'),
('GLRS2B', 'L2', 'GLRS2'),
('L1B', 'L1', 'GLRS');

-- --------------------------------------------------------

--
-- Structure de la table `cours`
--

DROP TABLE IF EXISTS `cours`;
CREATE TABLE IF NOT EXISTS `cours` (
  `idCours` int(11) NOT NULL AUTO_INCREMENT,
  `dateCours` date NOT NULL,
  `libelleCl` varchar(255) NOT NULL,
  `matriculeProf` varchar(255) NOT NULL,
  `libelleMod` varchar(255) NOT NULL,
  `semestre` varchar(255) NOT NULL,
  `volumeHoraire` int(10) NOT NULL,
  `heureDeb` time NOT NULL,
  `heureFin` time NOT NULL,
  `idProf` int(11) NOT NULL,
  PRIMARY KEY (`idCours`),
  KEY `libelleCl` (`libelleCl`),
  KEY `matriculeProf` (`matriculeProf`),
  KEY `libelleMod` (`libelleMod`),
  KEY `idProf` (`idProf`)
) ENGINE=MyISAM AUTO_INCREMENT=15 DEFAULT CHARSET=latin1;

--
-- Déchargement des données de la table `cours`
--

INSERT INTO `cours` (`idCours`, `dateCours`, `libelleCl`, `matriculeProf`, `libelleMod`, `semestre`, `volumeHoraire`, `heureDeb`, `heureFin`, `idProf`) VALUES
(1, '2021-06-03', 'GLRS2A', 'AVF-FRT-JJU', 'JAVA', '1', 40, '14:00:00', '16:00:00', 4),
(2, '2021-06-03', 'GLRS2B', 'EFR-TRG-YTY', 'C++', '1', 40, '14:00:00', '16:00:00', 16),
(3, '2021-06-10', 'MAE2', 'DFG-FRG-FER', 'MATHS', '2', 60, '08:00:00', '12:00:00', 18),
(4, '2021-10-03', 'L1B', 'AZE-DER-ERT', 'HTML', '2', 20, '12:00:00', '14:00:00', 17),
(7, '2021-06-01', 'GLRS2A', 'DFG-FRG-FER', 'MODELISATION', '1', 60, '10:00:00', '12:00:00', 18),
(8, '2021-07-02', 'MAE2', 'AVF-FRT-JJU', 'C#', '1', 40, '08:00:00', '12:00:00', 4),
(9, '2021-07-04', 'MAE2', 'EFR-TRG-YTY', 'ALGO', '2', 40, '10:00:00', '14:00:00', 16),
(10, '2021-07-04', 'MAE2', 'EFR-TRG-YTY', 'ALGO', '2', 40, '10:00:00', '14:00:00', 16),
(11, '2021-07-04', 'MAE2', 'EFR-TRG-YTY', 'ALGO', '2', 40, '10:00:00', '14:00:00', 16),
(12, '2021-07-09', 'GLRS2B', 'EFR-TRG-YTY', 'C++', '1', 20, '08:00:00', '10:00:00', 16),
(13, '2021-07-09', 'GLRS2B', 'EFR-TRG-YTY', 'C++', '1', 20, '08:00:00', '10:00:00', 16),
(14, '2021-07-10', 'MAE2', 'EFR-TRG-YTY', 'UML', '2', 40, '10:00:00', '12:00:00', 38);

-- --------------------------------------------------------

--
-- Structure de la table `etudiant`
--

DROP TABLE IF EXISTS `etudiant`;
CREATE TABLE IF NOT EXISTS `etudiant` (
  `matriculeEtu` varchar(255) NOT NULL,
  `nomEtu` varchar(255) NOT NULL,
  `prenomEtu` varchar(255) NOT NULL,
  `dateNaisEtu` date NOT NULL,
  `sexeEtu` varchar(255) NOT NULL,
  `roleEtu` varchar(255) NOT NULL,
  `avatarEtu` varchar(255) NOT NULL,
  `libelleCl` varchar(255) NOT NULL,
  `competenceEtu` varchar(255) NOT NULL,
  `parcoursEtu` varchar(255) DEFAULT NULL,
  `id` int(11) NOT NULL,
  PRIMARY KEY (`matriculeEtu`),
  KEY `libelleCl` (`libelleCl`),
  KEY `id` (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Déchargement des données de la table `etudiant`
--

INSERT INTO `etudiant` (`matriculeEtu`, `nomEtu`, `prenomEtu`, `dateNaisEtu`, `sexeEtu`, `roleEtu`, `avatarEtu`, `libelleCl`, `competenceEtu`, `parcoursEtu`, `id`) VALUES
('EFR-TRE-REF', 'Fall', 'Modou', '2000-03-12', 'masculin', 'etudiant', 'vilain', 'L1B', 'bon', NULL, 7),
('ABR-GRT-LLR', 'Babou', 'Mouhamed', '2002-10-14', 'masculin', 'etudiant', 'beau', 'MAE2', 'Mathématiques', 'parcours très riche', 6),
('ABC-DEF-GHI', 'MBAYE', 'Arame', '2001-05-18', 'feminin', 'Etudiant', 'belle', 'GLRS2A', 'developpement', ' riche parcours', 11),
('ABR-SFD-LLR', 'GUEYE', 'Bineta', '2002-01-20', 'feminin', 'etudiant', 'belle', 'GLRS2B', 'developpement', 'parcours très riche', 8),
('AZE-RET-SEZ', 'GAYE', 'Moustapha', '2001-07-10', 'masculin', 'etudiant', 'vilain', 'MAE2', 'il est nul', 'bah je sais pas', 9),
('AZM-RET-SEA', 'YAMEOGO', 'Ivan', '2002-07-14', 'masculin', 'etudiant', 'beau', 'MAE2', 'maths et developpement', 'riche parcours', 10);

-- --------------------------------------------------------

--
-- Structure de la table `module`
--

DROP TABLE IF EXISTS `module`;
CREATE TABLE IF NOT EXISTS `module` (
  `libelleMod` varchar(255) NOT NULL,
  PRIMARY KEY (`libelleMod`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Déchargement des données de la table `module`
--

INSERT INTO `module` (`libelleMod`) VALUES
('ALGO'),
('JAVA'),
('maths'),
('UML');

-- --------------------------------------------------------

--
-- Structure de la table `professeur`
--

DROP TABLE IF EXISTS `professeur`;
CREATE TABLE IF NOT EXISTS `professeur` (
  `matriculeProf` varchar(255) NOT NULL,
  `nomProf` varchar(255) NOT NULL,
  `prenomProf` varchar(255) NOT NULL,
  `dateNaisProf` date NOT NULL,
  `sexeProf` varchar(255) NOT NULL,
  `gradeProf` varchar(255) NOT NULL,
  `roleProf` varchar(255) NOT NULL,
  `avatarProf` varchar(255) NOT NULL,
  `libelleCl` varchar(255) NOT NULL,
  `libelleMod` varchar(255) NOT NULL,
  `id` int(11) NOT NULL,
  PRIMARY KEY (`matriculeProf`),
  KEY `libelleCl` (`libelleCl`),
  KEY `libelleMod` (`libelleMod`),
  KEY `id` (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Déchargement des données de la table `professeur`
--

INSERT INTO `professeur` (`matriculeProf`, `nomProf`, `prenomProf`, `dateNaisProf`, `sexeProf`, `gradeProf`, `roleProf`, `avatarProf`, `libelleCl`, `libelleMod`, `id`) VALUES
('AVF-FRT-JJU', 'Wane', 'Bailla', '1980-10-20', 'masculin', 'ingenieur', 'prof', 'ah je ne sais pas', 'GLRSA', 'JAVA', 4),
('EFR-TRG-YTY', 'DER', 'Moustapha', '1975-10-23', 'masculin', 'ingénieur', 'prof', 'ah je ne sais pas\r\n', 'GLRSB', 'C++', 16),
('AZE-DER-ERT', 'Sangare', 'Mouhamed', '1985-10-20', 'masculin', 'ingenieur', 'prof', 'ah je ne sais pas', 'L1B', 'HTML', 17),
('DFG-FRG-FER', 'DIOMPY', 'Albert', '1980-10-13', 'masculin', 'professeur', 'prof', 'ah je ne sais pas\r\n', 'MAE2', 'MATHS', 18);

-- --------------------------------------------------------

--
-- Structure de la table `user`
--

DROP TABLE IF EXISTS `user`;
CREATE TABLE IF NOT EXISTS `user` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `nom_complet` varchar(255) NOT NULL,
  `login` varchar(255) NOT NULL,
  `password` varchar(255) NOT NULL,
  `avatar` varchar(255) NOT NULL,
  `role` varchar(255) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=48 DEFAULT CHARSET=latin1;

--
-- Déchargement des données de la table `user`
--

INSERT INTO `user` (`id`, `nom_complet`, `login`, `password`, `avatar`, `role`) VALUES
(31, 'modou', 'admin@gmail.com', '$2y$10$N2gGhX3V72kzFNDd/Wn/nuX05iYgAwEI.JqdOOVwg.V2N0fbzZJYC', 'ah', 'ROLE_ADMIN'),
(35, 'Moustapha GAYE', 'gaye@gmail.com', '$2y$10$jJeqGp412auLRbFoMxKfZO1Od4rw1eedU3hfSINFbXLk96M/gLcQ6', 'AH', 'ROLE_AC'),
(36, 'Rassoul babou', 'sarr@gmail.com', '$2y$10$rr2sTOvLE/UlhfLrBPOhqeezuysL5OwkNIuEAxPKro1z1lLlOb8pC', 'ah', 'ROLE_ETUDIANT'),
(37, 'diarra mbaye', 'mbaye@gmail.com', '$2y$10$VXcRBhEHvKo5M6tAtfQBqOmaOTEMyXu7o5GLBz6rYBCRFmsEJZGMq', 'ah', 'ROLE_RP'),
(38, 'Bailla wane', 'wane@gmail.com', '$2y$10$o8nZRQGHIpNd5U8uaYNtreZZuHNKj44ZWv20whAAUjck07xRAdzKq', 'AH', 'ROLE_PROF'),
(39, 'aaaa                 aaaaaaa        ', '99omar@gmail.com', '$2y$10$D7M6ms5FMejvZjobX25CMuFVpqf5FJUf1q45MbQ3t2FZaePPTCR0W', 'logo-cax.png', 'ROLE_PROF'),
(40, 'Mouhamed                         omar', 'moustapha0903g@gmail.com', '$2y$10$R4FJr/MxPy6WGOa4etBgvegp4GDXCXwKPZW5TPUiIxMpE7LUg7CYi', 'upload/', 'ROLE_PROF'),
(41, 'diop ab', 'ab@gmail.com', '$2y$10$Vc3TjVD5iFBN8yZkRxK45.0/0U450KJX/IA9cKakQRKpPf746/adG', 'upload/', 'ROLE_PROF'),
(42, 'diop abvvvv', 'gggab@gmail.com', '$2y$10$YWXImVXgGaW/NihW6xmAces8R8.ItWqUmR1p53hjpQDhvrvf2N1Am', 'upload/logo-cax.png', 'ROLE_PROF'),
(43, 'SEBENE MOUAH', 'sene@gmail.com', '$2y$10$QtZjoXxvFxVSf6OUCHcrvu15xG7r0IWD9XmHnk3j3dh1gYFttXO7y', 'upload/logo-cax.png', 'ROLE_PROF'),
(44, 'Moustapha omar', 'sarr@gmail.com1', '$2y$10$M3HBy47qKq6Sv2j.7MvfweQg2CMyJgzc/fWoksnx8J6WaNA24zXn2', 'public/upload/logo-cax.png', 'ROLE_PROF'),
(45, 'falll awa', 'fall@gmail.com', '$2y$10$KVarPsYkK1luz49.gZqIaeADGO6327L08mr.jXeaW0z86MxeQyu92', 'C:\\Users\\DELL\\Desktop\\PHP PROJET\\getionEtudiant\\upload/logo-cax.png', 'ROLE_PROF'),
(46, 'diop fall', 'falll@gmail.com', '$2y$10$yQwVusJCr7StRiGUSLDRJOSxajE5/nIr50GwJ1.X6OHCg.cz1GHOa', 'C:\\Users\\DELL\\Desktop\\PHP PROJET\\getionEtudiant\\upload\\logo-cax.png', 'ROLE_PROF');
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
